#ifndef __BTTERMINAL_H__
#define __BTTERMINAL_H__


extern void btterminal_init(void);
extern void btterminal_send(uint8_t *buffer, int len);
extern void btlog(const char *format, ...);

#endif /* __BTTERMINAL_H__ */

