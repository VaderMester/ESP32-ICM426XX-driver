#ifndef _FONTS_H_
#define _FONTS_H_


#include <gfxfont.h>

#include <kongtext4pt7b.h>
#include <FreeMono9pt7b.h>
#include <FreeMono12pt7b.h>
#include <FreeSansBoldOblique12pt7b.h>
#include <FreeMono18pt7b.h>
#include <FreeSansBoldOblique18pt7b.h>
#include <FreeMono24pt7b.h>
#include <FreeSansBoldOblique24pt7b.h>
#include <FreeSansBoldOblique9pt7b.h>
#include <FreeMonoBold12pt7b.h>
#include <FreeSansOblique12pt7b.h>
#include <FreeMonoBold18pt7b.h>
#include <FreeSansOblique18pt7b.h>
#include <FreeMonoBold24pt7b.h>
#include <FreeSansOblique24pt7b.h>
#include <FreeMonoBold9pt7b.h>
#include <FreeSansOblique9pt7b.h>
#include <FreeMonoBoldOblique12pt7b.h>
#include <FreeSerif12pt7b.h>
#include <FreeMonoBoldOblique18pt7b.h>
#include <FreeSerif18pt7b.h>
#include <FreeMonoBoldOblique24pt7b.h>
#include <FreeSerif24pt7b.h>
#include <FreeMonoBoldOblique9pt7b.h>
#include <FreeSerif9pt7b.h>
#include <FreeMonoOblique12pt7b.h>
#include <FreeSerifBold12pt7b.h>
#include <FreeMonoOblique18pt7b.h>
#include <FreeSerifBold18pt7b.h>
#include <FreeMonoOblique24pt7b.h>
#include <FreeSerifBold24pt7b.h>
#include <FreeMonoOblique9pt7b.h>
#include <FreeSerifBold9pt7b.h>
#include <FreeSans12pt7b.h>
#include <FreeSerifBoldItalic12pt7b.h>
#include <FreeSans18pt7b.h>
#include <FreeSerifBoldItalic18pt7b.h>
#include <FreeSans24pt7b.h>
#include <FreeSerifBoldItalic24pt7b.h>
#include <FreeSans9pt7b.h>
#include <FreeSerifBoldItalic9pt7b.h>
#include <FreeSansBold12pt7b.h>
#include <FreeSerifItalic12pt7b.h>
#include <FreeSansBold18pt7b.h>
#include <FreeSerifItalic18pt7b.h>
#include <FreeSansBold24pt7b.h>
#include <FreeSerifItalic24pt7b.h>
#include <FreeSansBold9pt7b.h>
#include <FreeSerifItalic9pt7b.h>

#endif