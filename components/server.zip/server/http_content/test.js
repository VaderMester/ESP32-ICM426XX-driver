document.getElementById("websocketstatus").innerHTML = "Not connected";

var websocket = new WebSocket('ws://'+location.hostname+'/');

var sendbutton = document.getElementById("send");
var counter = 0;



sendbutton.onclick = function() {
  websocket.send(document.getElementById("websocketcommand").value);
}


websocket.onopen = function(evt) {
  document.getElementById("websocketstatus").innerHTML = "Connected!";
}


function ab2str(buf) {
  return new Uint8Array(buf).toString();
}


websocket.onmessage = function(evt) {
  counter++;
  if(typeof evt.data === 'string') {
    document.getElementById("websocketdata").value = counter + " Text data received:\n" + evt.data;
  } else {
    var reader = new FileReader();
    reader.readAsArrayBuffer(evt.data);
    reader.addEventListener("loadend", function(e) {
      document.getElementById("websocketdata").value = counter + " Binary data received in " + e.target.result.byteLength + " long octet stream: " + ab2str(e.target.result);
    });
  }
}

websocket.onclose = function(evt) {
  document.getElementById("websocketstatus").innerHTML = "Closed";
}

websocket.onerror = function(evt) {
  document.getElementById("websocketstatus").innerHTML = "Error";
}

