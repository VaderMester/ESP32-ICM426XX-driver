#ifndef __SERVER_H__
#define __SERVER_H__

#include <stdio.h>
#include <esp_system.h>

extern esp_err_t server_init(void);

extern void wifilog(const char *format, ...);
extern void wifilog_from_cb(const char *format, ...);

#endif /* __SERVER_H__ */
